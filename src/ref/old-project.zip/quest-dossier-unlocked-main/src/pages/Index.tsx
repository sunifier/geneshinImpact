import React from 'react';
import { DossierProvider, useDossier } from '@/context/DossierContext';
import { LoginOverlay } from '@/components/dossier/LoginOverlay';
import { StickyHUD } from '@/components/dossier/StickyHUD';
import { SidebarNav } from '@/components/dossier/SidebarNav';
import { CompletionModal } from '@/components/dossier/CompletionModal';
import { OpeningFrameSection } from '@/components/dossier/sections/OpeningFrameSection';
import { EvidenceBoard } from '@/components/dossier/sections/EvidenceBoard';
import { CaseBriefSection } from '@/components/dossier/sections/CaseBriefSection';
import { EvidenceIntakeSection } from '@/components/dossier/sections/EvidenceIntakeSection';
import { ForensicsLabSection } from '@/components/dossier/sections/ForensicsLabSection';
import { SegmentationRoomSection } from '@/components/dossier/sections/SegmentationRoomSection';
import { RiskEngineSection } from '@/components/dossier/sections/RiskEngineSection';
import { PublicVoiceSection } from '@/components/dossier/sections/PublicVoiceSection';
import { CrossViewMeaningSection } from '@/components/dossier/sections/CrossViewMeaningSection';
import { DeploymentPlanSection } from '@/components/dossier/sections/DeploymentPlanSection';
import { FinalVerdictSection } from '@/components/dossier/sections/FinalVerdictSection';
import { ValidationSection } from '@/components/dossier/sections/ValidationSection';
import { DiagnosticsSection } from '@/components/dossier/sections/DiagnosticsSection';
import { Toaster } from '@/components/ui/toaster';

function DossierApp() {
  const { state } = useDossier();

  if (!state.isLoggedIn) {
    return <LoginOverlay />;
  }

  const isInternal = state.viewMode === 'internal';

  return (
    <div className="min-h-screen">
      <StickyHUD />
      <div className="flex gap-4 p-4 max-w-[1600px] mx-auto" style={{ minHeight: 'calc(100vh - 80px)' }}>
        <SidebarNav />
        <main className="flex-1 min-w-0">
          <OpeningFrameSection />
          <EvidenceBoard />
          <CaseBriefSection />
          <EvidenceIntakeSection />
          <ForensicsLabSection />
          <SegmentationRoomSection />
          <RiskEngineSection />
          <PublicVoiceSection />
          <CrossViewMeaningSection />
          <DeploymentPlanSection />
          <FinalVerdictSection />
          {isInternal && <ValidationSection />}
          {isInternal && <DiagnosticsSection />}
        </main>
      </div>
      <CompletionModal />
    </div>
  );
}

const Index = () => (
  <DossierProvider>
    <DossierApp />
    <Toaster />
  </DossierProvider>
);

export default Index;
