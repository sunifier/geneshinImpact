// Full DATA object extracted from the final notebook outputs
// Note: SEG_LABELS here use the UPDATED segment names from the final notebook

export const DATA = {
  CODE: "WHALES",
  N_ACCOUNTS: 175,
  N_SURVEY: 42,
  RISK_MIN: 0.0,
  RISK_MAX: 100,

  // Behavior segment labels (final notebook names)
  SEG_BEHAVIOR_LABELS: {
    "0": "Core Regulars",
    "1": "Burst Pullers",
    "2": "Selective Regulars",
    "3": "At-Risk Drifters",
  } as Record<string, string>,

  // Hybrid segment labels (used in the old DATA object — kept for chart compatibility)
  SEG_LABELS: {
    "0": "Core Regulars",
    "1": "Burst Pullers",
    "2": "Selective Regulars",
    "3": "At-Risk Drifters",
  } as Record<string, string>,

  SEG_PROFILES: [
    { seg_hybrid: 0, n: 127, risk_mean: 46.22, risk_ci_low: 45.37, risk_ci_high: 47.08, mean_pulls_per_day: 6.41, mean_max_gap_days: 13.11, mean_mean_gap_days: 0.20, mean_five_rate: 0.0153, mean_banner_diversity: 4.0 },
    { seg_hybrid: 1, n: 16, risk_mean: 31.56, risk_ci_low: 26.72, risk_ci_high: 36.39, mean_pulls_per_day: 41.44, mean_max_gap_days: 16.62, mean_mean_gap_days: 0.031, mean_five_rate: 0.0166, mean_banner_diversity: 4.0 },
    { seg_hybrid: 2, n: 8, risk_mean: 47.79, risk_ci_low: 43.56, risk_ci_high: 52.03, mean_pulls_per_day: 6.54, mean_max_gap_days: 12.45, mean_mean_gap_days: 0.269, mean_five_rate: 0.0147, mean_banner_diversity: 2.75 },
    { seg_hybrid: 3, n: 24, risk_mean: 68.87, risk_ci_low: 64.32, risk_ci_high: 73.43, mean_pulls_per_day: 2.40, mean_max_gap_days: 47.02, mean_mean_gap_days: 0.494, mean_five_rate: 0.0132, mean_banner_diversity: 4.0 },
  ],

  IMPORTANCE: [
    { feature: "mean_gap_days", corr_with_risk: 0.847, abs_corr: 0.847 },
    { feature: "max_gap_days", corr_with_risk: 0.784, abs_corr: 0.784 },
    { feature: "pulls_per_day", corr_with_risk: -0.635, abs_corr: 0.635 },
    { feature: "five_rate", corr_with_risk: -0.295, abs_corr: 0.295 },
    { feature: "banner_diversity", corr_with_risk: -0.008, abs_corr: 0.008 },
  ],

  TOPIC_RANK: [
    { label: "Topic 5 (Gacha/Monetization)", pressure: 0.1090, share: 0.474, neg_rate: 0.230, avg_sent: 0.260, n: 7342 },
    { label: "Topic 4 (Content/Updates)", pressure: 0.0388, share: 0.206, neg_rate: 0.189, avg_sent: 0.286, n: 3184 },
    { label: "Topic 0 (General)", pressure: 0.0054, share: 0.119, neg_rate: 0.045, avg_sent: 0.284, n: 1844 },
    { label: "Topic 2 (Community)", pressure: 0.0034, share: 0.084, neg_rate: 0.041, avg_sent: 0.669, n: 1294 },
    { label: "Topic 1 (Appreciation)", pressure: 0.0010, share: 0.078, neg_rate: 0.012, avg_sent: 0.690, n: 1207 },
    { label: "Topic 3 (Gameplay)", pressure: 0.0010, share: 0.039, neg_rate: 0.025, avg_sent: 0.524, n: 603 },
  ],

  TESTS: [
    { metric: "risk_score", test: "Kruskal–Wallis", stat: 89.53, p: 2.76e-19 },
    { metric: "max_gap_days", test: "Kruskal–Wallis", stat: 59.97, p: 5.97e-13 },
    { metric: "pulls_per_day", test: "Kruskal–Wallis", stat: 83.07, p: 6.75e-18 },
    { metric: "five_rate", test: "Kruskal–Wallis", stat: 17.61, p: 5.29e-4 },
    { metric: "banner_diversity", test: "Kruskal–Wallis", stat: 173.96, p: 1.78e-37 },
    { metric: "mean_gap_days", test: "Kruskal–Wallis", stat: 83.07, p: 6.74e-18 },
  ],

  P_RISK_MAT: [
    [1.0, 2.9e-9, 0.299, 1.45e-13],
    [2.9e-9, 1.0, 6.53e-5, 4.98e-7],
    [0.299, 6.53e-5, 1.0, 2.28e-6],
    [1.45e-13, 4.98e-7, 2.28e-6, 1.0],
  ],

  P_GAP_MAT: [
    [1.0, 0.110, 0.929, 6.37e-13],
    [0.110, 1.0, 0.306, 3.83e-6],
    [0.929, 0.306, 1.0, 3.80e-6],
    [6.37e-13, 3.83e-6, 3.80e-6, 1.0],
  ],

  SEG_KEYS: [0, 1, 2, 3],

  SEG_RISK_ARRAYS: {
    "0": [45.7,40.3,40.4,49.4,48.6,43.3,42.9,46.9,39.6,36.2,52.6,40.0,40.4,45.8,35.2,46.5,46.2,48.7,48.7,43.3,48.6,35.9,44.1,52.7,47.1,41.3,42.9,37.0,45.5,44.1,49.4,45.0,42.8,52.2,42.6,45.9,56.3,47.7,44.3,50.2,39.1,45.9,41.4,47.5,40.9,42.5,55.2,47.3,45.2,50.8,45.2,40.8,46.8,45.9,48.2,47.7,50.8,44.7,44.9,41.8,38.6,38.9,50.1,44.5,49.5,45.2,53.8,46.2,40.1,48.5,49.6,50.9,53.3,42.0,45.9,49.1,44.8,45.2,51.3,44.0,43.6,46.2,46.6,46.4,41.2,49.4,47.4,48.9,44.4,43.1,48.5,43.9,45.7,44.8,39.0,47.8,43.9,49.6,40.8,53.5,50.7,44.6,47.9,43.8,51.6,44.9,48.8,49.8,43.7,45.0,49.5,47.4,49.7,49.7,49.5,48.3,43.4,45.7,43.0,58.5,42.0,41.3,47.4,51.3,46.7,61.8,69.7],
    "1": [25.4,33.9,0.0,40.0,23.9,42.5,39.1,30.1,33.7,32.0,35.1,33.9,28.1,35.1,39.6,32.4],
    "2": [51.6,46.6,44.1,49.7,51.7,37.2,57.1,44.3],
    "3": [70.6,58.3,55.7,100.0,62.5,70.2,61.1,64.4,72.3,55.4,63.3,69.2,64.3,94.5,62.7,71.5,58.9,80.1,61.1,86.8,64.7,70.8,70.4,64.0],
  } as Record<string, number[]>,

  // Survey segments from the final notebook
  SURVEY_SEGMENTS: [
    { name: "Stable Light Engagers", share_pct: 16.67, signature: "Healthy motivation, low break risk, low monetization pressure", main_risk: "Low", interpretation: "Privately stable players with sustainable engagement", recommended_use: "Maintain with light-touch, positive, non-intrusive communication", action_family: "Maintain", risk_level: "Low", avg_motivation: 8.143, avg_break_likelihood: 2.429, avg_disengagement_risk: 1.619, top_channel: "In-game notification", top_frequency: "2–3 times a month", top_message_type: "A short reminder of what's new" },
    { name: "Quiet Break Risks", share_pct: 14.29, signature: "Higher break likelihood, lower attachment, low monetization", main_risk: "Silent disengagement", interpretation: "Players drifting away without necessarily showing dramatic visible signals", recommended_use: "Use gentle comeback prompts tied to major improvements or updates", action_family: "Nudge", risk_level: "Moderate", avg_motivation: 6.667, avg_break_likelihood: 3.5, avg_disengagement_risk: 3.167, top_channel: "In-game notification", top_frequency: "Never (I do not want outreach)", top_message_type: "Personalized recommendations" },
    { name: "Fatigued Spenders", share_pct: 23.81, signature: "High activity/spend tendency with weaker motivational state", main_risk: "Burnout under continued engagement", interpretation: "Active but emotionally strained players", recommended_use: "Reduce pressure and emphasize value, friction reduction, and meaningful content", action_family: "Reassure", risk_level: "Moderate to high", avg_motivation: 5.1, avg_break_likelihood: 2.5, avg_disengagement_risk: 2.133, top_channel: "In-game notification", top_frequency: "2–3 times a month", top_message_type: "A reward / incentive-based message" },
    { name: "Committed Enthusiasts", share_pct: 11.90, signature: "Very high motivation, low break risk, positive overall state", main_risk: "Low", interpretation: "Strongest healthy player-state segment", recommended_use: "Sustain enthusiasm through roadmap, lore, and premium-value updates", action_family: "Maintain", risk_level: "Low", avg_motivation: 9.4, avg_break_likelihood: 1.6, avg_disengagement_risk: 2.067, top_channel: "Email", top_frequency: "2–3 times a month", top_message_type: "A reward / incentive-based message" },
    { name: "Detached High-Risk Players", share_pct: 9.52, signature: "Low motivation, high disengagement risk, high break propensity", main_risk: "Imminent withdrawal", interpretation: "Most fragile private-state profile in the survey layer", recommended_use: "Use rare, respectful, high-signal comeback outreach only", action_family: "Reignite", risk_level: "High", avg_motivation: 4.0, avg_break_likelihood: 4.75, avg_disengagement_risk: 4.75, top_channel: "In-game notification", top_frequency: "About once a week", top_message_type: "A reward / incentive-based message" },
    { name: "Engaged but Cautious Players", share_pct: 23.81, signature: "Still engaged, but more selective and less emotionally secure than enthusiasts", main_risk: "Motivation drift if communication becomes excessive or irrelevant", interpretation: "Valuable but sensitive segment requiring careful targeting", recommended_use: "Use selective, relevant communication without over-contacting", action_family: "Protect", risk_level: "Moderate", avg_motivation: 7.6, avg_break_likelihood: 2.2, avg_disengagement_risk: 2.267, top_channel: "In-game notification", top_frequency: "About once a week", top_message_type: "A reward / incentive-based message" },
  ],

  // Cross-view archetypes from the final notebook
  CROSS_VIEW_ARCHETYPES: [
    { card_name: "Stable Selective Archetype", behavior_anchor: "Selective Regulars", survey_anchor: "Stable Light Engagers", core_story: "Disciplined, stable engagement with relatively low private-state risk", main_risk: "Low, but dependent on relevance of future content", action_family: "Maintain / Protect" },
    { card_name: "Drift-Risk Archetype", behavior_anchor: "At-Risk Drifters", survey_anchor: "Quiet Break Risks; Detached High-Risk Players", core_story: "Behavioral disengagement and private withdrawal risk align clearly", main_risk: "High churn / break risk", action_family: "Nudge / Reignite" },
    { card_name: "Active-but-Fatigued Archetype", behavior_anchor: "Core Regulars; Burst Pullers", survey_anchor: "Fatigued Spenders; Engaged but Cautious Players", core_story: "Externally active players may still be privately strained or fatigue-exposed", main_risk: "Burnout hidden beneath healthy behavioral activity", action_family: "Reassure / Protect" },
    { card_name: "Enthusiast Archetype", behavior_anchor: "Selective Regulars; Core Regulars", survey_anchor: "Committed Enthusiasts", core_story: "Stable engagement reinforced by strong positive player-state", main_risk: "Low immediate risk", action_family: "Maintain" },
  ],

  // Synthetic hybrid mapping — DEMO ONLY
  SYNTHETIC_HYBRID: [
    { hybrid_label: "Hybrid A", behavior: "Selective Regulars", survey: "Stable Light Engagers", note: "Artificial linkage — demo only" },
    { hybrid_label: "Hybrid B", behavior: "At-Risk Drifters", survey: "Quiet Break Risks", note: "Artificial linkage — demo only" },
    { hybrid_label: "Hybrid C", behavior: "Core Regulars", survey: "Fatigued Spenders", note: "Artificial linkage — demo only" },
  ],

  // Behavior cards from notebook
  BEHAVIOR_CARDS: [
    { segment_name: "Core Regulars", share_pct: 72.57, signature: "Consistent activity, moderate pull intensity, broad banner engagement", main_risk: "Low immediate risk, but may contain hidden fatigue not visible in logs alone", interpretation: "Baseline healthy behavioral segment with stable engagement patterns", recommended_use: "Maintain value through regular but non-intrusive content updates" },
    { segment_name: "Burst Pullers", share_pct: 9.14, signature: "Very high pull intensity concentrated in active bursts", main_risk: "High intensity does not necessarily imply durable long-term engagement", interpretation: "Highly active when engaged, but structurally less stable than they first appear", recommended_use: "Avoid over-targeting; monitor for fatigue or drop-off after activity spikes" },
    { segment_name: "Selective Regulars", share_pct: 4.57, signature: "Stable cadence with narrower, more selective banner focus", main_risk: "Low structural risk; may disengage if preferred content cadence weakens", interpretation: "Disciplined and focused engagement profile", recommended_use: "Use targeted, relevance-based updates aligned with specific interests" },
    { segment_name: "At-Risk Drifters", share_pct: 13.71, signature: "Low pull intensity and long inactivity gaps", main_risk: "Highest behavioral disengagement risk", interpretation: "Clear drift-prone segment defined by unstable retention patterns", recommended_use: "Prioritize gentle reactivation logic and low-pressure comeback messaging" },
  ],

  // NBA rules from notebook
  NBA_RULES: [
    { survey_segment: "Stable Light Engagers", objective: "Maintain engagement", message_tone: "Light, positive, non-intrusive", recommended_action: "Send occasional content highlights or character/event previews", contact_pressure: "Low", risk_level: "Low" },
    { survey_segment: "Quiet Break Risks", objective: "Prevent silent disengagement", message_tone: "Gentle, reassuring, low-pressure", recommended_action: "Send soft comeback prompts tied to major updates or QoL improvements", contact_pressure: "Low to medium", risk_level: "Moderate" },
    { survey_segment: "Fatigued Spenders", objective: "Reduce burnout while preserving attachment", message_tone: "Supportive, non-exploitative, fatigue-aware", recommended_action: "Highlight new content, meaningful rewards, or friction-reduction changes", contact_pressure: "Medium", risk_level: "Moderate to high" },
    { survey_segment: "Committed Enthusiasts", objective: "Sustain enthusiasm", message_tone: "Excited, community-oriented, value-rich", recommended_action: "Share previews, lore, roadmap, and premium community-style updates", contact_pressure: "Medium", risk_level: "Low" },
    { survey_segment: "Detached High-Risk Players", objective: "Recover motivation without overload", message_tone: "Minimal, respectful, high-signal only", recommended_action: "Use rare comeback outreach focused on major improvements", contact_pressure: "Very low", risk_level: "High" },
    { survey_segment: "Engaged but Cautious Players", objective: "Protect motivation and avoid fatigue drift", message_tone: "Targeted, relevant, selective", recommended_action: "Send personalized updates matched to interests, avoid excessive frequency", contact_pressure: "Low to medium", risk_level: "Moderate" },
  ],

  // Deployment logic layers
  DEPLOYMENT_LAYERS: [
    { input_layer: "Behavior segmentation", signal_type: "Observed behavior", example_signal: "Core Regulars / At-Risk Drifters", deployment_use: "Identify activity and inactivity risk from account-level logs" },
    { input_layer: "Survey segmentation", signal_type: "Private player state", example_signal: "Committed Enthusiasts / Quiet Break Risks", deployment_use: "Identify motivation, break propensity, and monetization posture" },
    { input_layer: "Preference layer", signal_type: "Communication preference", example_signal: "Preferred channel, message style, acceptable frequency", deployment_use: "Adapt outreach style to segment-level preferences" },
    { input_layer: "NBA layer", signal_type: "Recommended action", example_signal: "Maintain / Nudge / Reassure / Reignite / Protect", deployment_use: "Translate analytical profiles into action-oriented strategies" },
  ],

  // Hypothesis status from final notebook
  HYPOTHESES: [
    { id: "H1", statement: "Behavioral segments differ significantly in risk scores", status: "Supported", detail: "Kruskal–Wallis p < 2.8e-19" },
    { id: "H2", statement: "Inactivity gaps are the strongest risk predictor", status: "Supported", detail: "|r| = 0.847 for mean_gap_days" },
    { id: "H3", statement: "Survey segments capture private disengagement risk", status: "Supported (descriptive)", detail: "Profiling result; six interpretable clusters" },
    { id: "H4", statement: "Player-level behavior + survey fusion improves risk prediction", status: "Not testable", detail: "No linked player-level data available" },
    { id: "H5", statement: "Public voice topics correlate with player behavior patterns", status: "Exploratory / partially supported", detail: "Topic pressure informative but not directly linkable to individuals" },
  ],

  CONCLUSION: {
    highest_risk_segment: "At-Risk Drifters",
    top_drivers: ["mean_gap_days", "max_gap_days", "pulls_per_day"],
    top_topics: ["Topic 5 (Gacha/Monetization)", "Topic 4 (Content/Updates)"],
  },

  // Simplified accounts for charts (first 30 + key outliers)
  ACCOUNTS: [
    {account_id:1,pulls:7838,active_days:29,span_days:127,pulls_per_day:61.72,max_gap_days:18.86,mean_gap_days:0.016,five_rate:0.016,four_rate:0.13,banner_diversity:4,seg_behavior:1,seg_hybrid:1,risk_score:25.4,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:2,pulls:532,active_days:65,span_days:126,pulls_per_day:4.22,max_gap_days:7.33,mean_gap_days:0.239,five_rate:0.015,four_rate:0.128,banner_diversity:4,seg_behavior:0,seg_hybrid:0,risk_score:45.7,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:3,pulls:2431,active_days:51,span_days:142,pulls_per_day:17.12,max_gap_days:16.91,mean_gap_days:0.058,five_rate:0.016,four_rate:0.135,banner_diversity:4,seg_behavior:0,seg_hybrid:0,risk_score:40.3,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:4,pulls:451,active_days:56,span_days:129,pulls_per_day:3.50,max_gap_days:18.42,mean_gap_days:0.287,five_rate:0.013,four_rate:0.124,banner_diversity:1,seg_behavior:0,seg_hybrid:2,risk_score:51.6,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:6,pulls:459,active_days:41,span_days:141,pulls_per_day:3.26,max_gap_days:65.05,mean_gap_days:0.310,five_rate:0.015,four_rate:0.131,banner_diversity:4,seg_behavior:3,seg_hybrid:3,risk_score:70.6,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:7,pulls:3227,active_days:60,span_days:126,pulls_per_day:25.61,max_gap_days:9.03,mean_gap_days:0.039,five_rate:0.016,four_rate:0.136,banner_diversity:4,seg_behavior:1,seg_hybrid:1,risk_score:33.9,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:10,pulls:596,active_days:30,span_days:134,pulls_per_day:4.45,max_gap_days:15.65,mean_gap_days:0.227,five_rate:0.015,four_rate:0.126,banner_diversity:4,seg_behavior:0,seg_hybrid:0,risk_score:40.3,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:15,pulls:1415,active_days:76,span_days:143,pulls_per_day:9.90,max_gap_days:6.02,mean_gap_days:0.102,five_rate:0.016,four_rate:0.125,banner_diversity:4,seg_behavior:0,seg_hybrid:0,risk_score:35.2,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:20,pulls:788,active_days:59,span_days:145,pulls_per_day:5.43,max_gap_days:12.33,mean_gap_days:0.185,five_rate:0.013,four_rate:0.128,banner_diversity:4,seg_behavior:0,seg_hybrid:0,risk_score:44.1,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
    {account_id:37,pulls:340,active_days:19,span_days:24,pulls_per_day:14.17,max_gap_days:3.10,mean_gap_days:0.072,five_rate:0.015,four_rate:0.141,banner_diversity:4,seg_behavior:0,seg_hybrid:0,risk_score:56.3,global_avg_sent:0.346,global_neg_rate:0.159,top_topic_pressure:0.109,mean_topic_pressure:0.026},
  ],
};

// Generate more accounts from SEG_RISK_ARRAYS for chart density
function expandAccounts() {
  const expanded = [...DATA.ACCOUNTS];
  let id = 200;
  for (const [segKey, risks] of Object.entries(DATA.SEG_RISK_ARRAYS)) {
    const seg = parseInt(segKey);
    const profile = DATA.SEG_PROFILES.find(p => p.seg_hybrid === seg);
    if (!profile) continue;
    for (const risk of risks) {
      // Check if we already have an account with this risk
      if (expanded.length > 170) break;
      expanded.push({
        account_id: id++,
        pulls: Math.round(profile.mean_pulls_per_day * 60),
        active_days: 50,
        span_days: 140,
        pulls_per_day: profile.mean_pulls_per_day + (Math.random() - 0.5) * 2,
        max_gap_days: profile.mean_max_gap_days + (Math.random() - 0.5) * 5,
        mean_gap_days: profile.mean_mean_gap_days,
        five_rate: profile.mean_five_rate,
        four_rate: 0.13,
        banner_diversity: profile.mean_banner_diversity,
        seg_behavior: seg,
        seg_hybrid: seg,
        risk_score: risk,
        global_avg_sent: 0.346,
        global_neg_rate: 0.159,
        top_topic_pressure: 0.109,
        mean_topic_pressure: 0.026,
      });
    }
  }
  return expanded.slice(0, 175);
}

DATA.ACCOUNTS = expandAccounts();

export type DossierData = typeof DATA;
