import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

type ViewMode = 'client' | 'internal';

interface DossierState {
  isLoggedIn: boolean;
  viewMode: ViewMode;
  done: Record<string, boolean>;
  checklist: Record<string, boolean>;
}

interface DossierContextType {
  state: DossierState;
  login: (mode: ViewMode) => void;
  logout: () => void;
  markDone: (stepId: string) => void;
  toggleChecklist: (key: string) => void;
  resetProgress: () => void;
  progressSteps: () => { id: string; label: string }[];
  completedCount: number;
  totalSteps: number;
  progressPct: number;
  isComplete: boolean;
}

const STEPS = [
  { id: 'intro', label: 'Opening Frame' },
  { id: 'board', label: 'Evidence Board' },
  { id: 'brief', label: 'Case Brief' },
  { id: 'intake', label: 'Evidence Intake' },
  { id: 'forensics', label: 'Forensics Lab' },
  { id: 'segments', label: 'Segmentation Room' },
  { id: 'risk', label: 'Risk Engine' },
  { id: 'voice', label: 'Public Voice' },
  { id: 'crossview', label: 'Cross-View Meaning' },
  { id: 'deployment', label: 'Deployment Plan' },
  { id: 'verdict', label: 'Final Verdict' },
];

const INTERNAL_STEPS = [
  { id: 'validation', label: 'Validation' },
  { id: 'diagnostics', label: 'Diagnostics' },
];

// Steps that count as clues (exclude intro and board)
const CLUE_STEPS = STEPS.filter(s => s.id !== 'intro' && s.id !== 'board');
const CLUE_INTERNAL_STEPS = [...CLUE_STEPS, ...INTERNAL_STEPS];

const DossierContext = createContext<DossierContextType | null>(null);

function loadState(mode: ViewMode): { done: Record<string, boolean>; checklist: Record<string, boolean> } {
  try {
    const raw = localStorage.getItem(`silentwhale_progress_${mode}`);
    return raw ? JSON.parse(raw) : { done: {}, checklist: {} };
  } catch {
    return { done: {}, checklist: {} };
  }
}

function saveState(mode: ViewMode, done: Record<string, boolean>, checklist: Record<string, boolean>) {
  localStorage.setItem(`silentwhale_progress_${mode}`, JSON.stringify({ done, checklist }));
}

export function DossierProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<DossierState>({
    isLoggedIn: false,
    viewMode: 'client',
    done: {},
    checklist: {},
  });

  const login = useCallback((mode: ViewMode) => {
    const saved = loadState(mode);
    setState({ isLoggedIn: true, viewMode: mode, done: saved.done, checklist: saved.checklist });
  }, []);

  const logout = useCallback(() => {
    setState({ isLoggedIn: false, viewMode: 'client', done: {}, checklist: {} });
  }, []);

  const markDone = useCallback((stepId: string) => {
    setState(prev => {
      const newDone = { ...prev.done, [stepId]: true };
      saveState(prev.viewMode, newDone, prev.checklist);
      return { ...prev, done: newDone };
    });
  }, []);

  const toggleChecklist = useCallback((key: string) => {
    setState(prev => {
      const newChecklist = { ...prev.checklist, [key]: !prev.checklist[key] };
      saveState(prev.viewMode, prev.done, newChecklist);
      return { ...prev, checklist: newChecklist };
    });
  }, []);

  const resetProgress = useCallback(() => {
    setState(prev => {
      saveState(prev.viewMode, {}, {});
      return { ...prev, done: {}, checklist: {} };
    });
  }, []);

  const progressSteps = useCallback(() => {
    return state.viewMode === 'internal' ? [...STEPS, ...INTERNAL_STEPS] : STEPS;
  }, [state.viewMode]);

  const clueSteps = state.viewMode === 'internal' ? CLUE_INTERNAL_STEPS : CLUE_STEPS;
  const completedCount = clueSteps.filter(s => state.done[s.id]).length;
  const totalSteps = clueSteps.length;
  const progressPct = Math.round((completedCount / Math.max(1, totalSteps)) * 100);
  const isComplete = completedCount === totalSteps && totalSteps > 0;

  return (
    <DossierContext.Provider value={{
      state, login, logout, markDone, toggleChecklist, resetProgress,
      progressSteps, completedCount, totalSteps, progressPct, isComplete,
    }}>
      {children}
    </DossierContext.Provider>
  );
}

export function useDossier() {
  const ctx = useContext(DossierContext);
  if (!ctx) throw new Error('useDossier must be used within DossierProvider');
  return ctx;
}

export { STEPS, INTERNAL_STEPS };
