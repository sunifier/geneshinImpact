import React from 'react';
import { useDossier } from '@/context/DossierContext';
import { DATA } from '@/data/dossierData';

export function StickyHUD() {
  const { state, progressPct, completedCount, totalSteps, progressSteps } = useDossier();

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const steps = progressSteps();

  return (
    <div className="sticky top-0 z-50 border-b border-primary/20 no-print"
      style={{ background: 'hsla(216,50%,5%,0.88)', backdropFilter: 'blur(10px)' }}>
      <div className="flex items-center justify-between gap-3 px-4 py-3 max-w-[1600px] mx-auto">
        {/* Left */}
        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-primary font-black text-sm tracking-wider">Silent Whale — Quest Dossier</span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] border border-primary/20 text-muted-foreground">
              {state.viewMode}
            </span>
          </div>
          <span className="text-xs text-muted-foreground mt-1">
            {DATA.N_ACCOUNTS} accounts analyzed · {state.viewMode === 'internal' ? 'Full diagnostic access' : 'Executive findings view'}
          </span>
        </div>
        
        {/* Right */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Progress */}
          <div className="flex flex-col gap-1.5 min-w-[200px]">
            <div className="flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] border border-primary/20 text-muted-foreground">
                Progress: <strong className="text-foreground">{progressPct}%</strong>
              </span>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] border border-primary/20 text-muted-foreground">
                Clues: <strong className="text-foreground">{completedCount}</strong>/{totalSteps}
              </span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: 'hsla(0,0%,100%,0.08)' }}>
              <div className="h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPct}%`, background: 'linear-gradient(90deg, hsla(0,80%,58%,0.65), hsla(0,80%,58%,1))' }} />
            </div>
            <div className="flex gap-1.5 items-center">
              {steps.filter(s => s.id !== 'intro' && s.id !== 'board').map(s => (
                <div key={s.id}
                  className={`w-2 h-2 rounded-full border transition-colors ${
                    state.done[s.id]
                      ? 'bg-ok/80 border-ok/50'
                      : 'border-primary/20'
                  }`}
                  style={{ background: state.done[s.id] ? undefined : 'hsla(0,0%,100%,0.08)' }}
                  title={s.label} />
              ))}
            </div>
          </div>
          
          {/* Buttons */}
          <button onClick={() => scrollTo('board')}
            className="px-3 py-1.5 rounded-lg text-xs font-bold border border-primary/25 text-foreground hover:bg-primary/10 transition-all">
            Board
          </button>
          <button onClick={() => scrollTo('verdict')}
            className="px-3 py-1.5 rounded-lg text-xs font-bold border border-primary/25 text-foreground hover:bg-primary/10 transition-all">
            Verdict
          </button>
          <button onClick={() => window.print()}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-primary text-primary-foreground hover:brightness-105 transition-all">
            Print
          </button>
        </div>
      </div>
    </div>
  );
}
