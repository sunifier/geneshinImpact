import React from 'react';
import { useDossier } from '@/context/DossierContext';
import { DATA } from '@/data/dossierData';

export function CompletionModal() {
  const { isComplete } = useDossier();
  const [show, setShow] = React.useState(false);
  const c = DATA.CONCLUSION;

  React.useEffect(() => {
    if (isComplete) setShow(true);
  }, [isComplete]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[1001] flex items-center justify-center"
      style={{ background: 'hsla(0,0%,0%,0.55)' }}>
      <div className="glass-panel w-full max-w-[860px] mx-4 p-5 border border-primary/30">
        <h2 className="text-lg font-black text-primary tracking-wider">🏆 Case Completed</h2>
        <div className="text-sm text-muted-foreground mt-3 leading-relaxed space-y-2">
          <p><strong className="text-foreground">Highest-risk segment:</strong> {c.highest_risk_segment}</p>
          <p><strong className="text-foreground">Top risk-aligned drivers:</strong> {c.top_drivers.join(', ')}</p>
          <p><strong className="text-foreground">Highest-pressure topics:</strong> {c.top_topics.join(', ')}</p>
          <p className="mt-2">
            Verdict: prioritize interventions for the highest-risk segment, monitor inactivity gaps, 
            and use the NBA rules to tailor communication by player-state profile.
          </p>
        </div>
        <div className="flex gap-3 flex-wrap mt-4">
          <button onClick={() => setShow(false)}
            className="px-4 py-2 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:brightness-105">
            Continue
          </button>
          <button onClick={() => window.print()}
            className="px-4 py-2 rounded-xl border border-primary/30 text-foreground font-bold text-sm hover:bg-primary/10">
            Print dossier
          </button>
          <button onClick={() => { setShow(false); document.getElementById('verdict')?.scrollIntoView({ behavior: 'smooth' }); }}
            className="px-4 py-2 rounded-xl border border-primary/30 text-foreground font-bold text-sm hover:bg-primary/10">
            Go to Verdict
          </button>
        </div>
      </div>
    </div>
  );
}
