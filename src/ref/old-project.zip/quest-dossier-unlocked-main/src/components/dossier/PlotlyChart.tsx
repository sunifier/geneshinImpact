import React, { lazy, Suspense, useMemo } from 'react';

// Lazy load Plotly to avoid bundle bloat
const Plot = lazy(() => import('react-plotly.js'));

interface PlotlyChartProps {
  data: any[];
  layout?: any;
  style?: React.CSSProperties;
  className?: string;
}

const darkLayout = {
  paper_bgcolor: 'rgba(0,0,0,0)',
  plot_bgcolor: 'rgba(0,0,0,0)',
  font: { color: '#9aa4b2', size: 11 },
  margin: { t: 10, b: 40, l: 50, r: 10 },
  showlegend: false,
  xaxis: { gridcolor: 'rgba(255,255,255,0.05)', zerolinecolor: 'rgba(255,255,255,0.08)' },
  yaxis: { gridcolor: 'rgba(255,255,255,0.05)', zerolinecolor: 'rgba(255,255,255,0.08)' },
};

export function PlotlyChart({ data, layout, style, className }: PlotlyChartProps) {
  const mergedLayout = useMemo(() => ({
    ...darkLayout,
    ...layout,
    xaxis: { ...darkLayout.xaxis, ...(layout?.xaxis || {}) },
    yaxis: { ...darkLayout.yaxis, ...(layout?.yaxis || {}) },
  }), [layout]);

  return (
    <Suspense fallback={
      <div className="flex items-center justify-center h-64 text-muted-foreground text-sm">
        Loading chart...
      </div>
    }>
      <Plot
        data={data}
        layout={mergedLayout}
        style={{ width: '100%', height: '100%', ...style }}
        className={className}
        config={{ displayModeBar: false, responsive: true }}
        useResizeHandler
      />
    </Suspense>
  );
}
