import React, { useState } from 'react';
import { DATA } from '@/data/dossierData';
import { useDossier } from '@/context/DossierContext';

export function LoginOverlay() {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const { login } = useDossier();

  const handleLogin = (mode: 'client' | 'internal') => {
    if (code.trim().toUpperCase() !== DATA.CODE) {
      setError('Invalid access code.');
      return;
    }
    setError('');
    // Play login sound
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 440;
      osc.type = 'sine';
      gain.gain.value = 0.08;
      osc.start();
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.stop(ctx.currentTime + 0.4);
    } catch {}
    login(mode);
  };

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center"
      style={{ background: 'radial-gradient(circle at 20% 20%, hsla(0,80%,58%,0.12), hsla(216,50%,5%,0.96) 65%)' }}>
      <div className="glass-panel w-full max-w-[820px] mx-4 p-6">
        <h1 className="text-xl font-black tracking-wider text-primary">Access Portal</h1>
        <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
          Enter access code to unlock the <span className="text-foreground font-semibold">Silent Whale — Quest Dossier</span>.
          <br />Choose <strong>Client</strong> for a narrative-focused executive view, or <strong>Internal</strong> for full diagnostic access.
        </p>
        
        <div className="flex gap-3 flex-wrap mt-5 items-center">
          <input
            value={code}
            onChange={e => { setCode(e.target.value); setError(''); }}
            onKeyDown={e => e.key === 'Enter' && handleLogin('client')}
            placeholder="Access code"
            className="flex-1 min-w-[220px] px-3 py-2.5 rounded-xl border border-primary/20 bg-background text-foreground outline-none focus:border-primary/50 transition-colors"
          />
          <button onClick={() => handleLogin('client')}
            className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:brightness-105 transition-all">
            Client View
          </button>
          <button onClick={() => handleLogin('internal')}
            className="px-4 py-2.5 rounded-xl border border-primary/30 text-foreground font-bold text-sm hover:bg-primary/10 transition-all">
            Internal View
          </button>
        </div>
        
        {error && <p className="text-primary text-xs mt-3 font-semibold">{error}</p>}
        <p className="text-foreground/60 text-xs mt-3">Hint: the code is in the project brief.</p>
      </div>
    </div>
  );
}
