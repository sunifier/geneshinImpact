import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';
import { useDossier } from '@/context/DossierContext';
import { toast } from '@/hooks/use-toast';

export function DeploymentPlanSection() {
  const { state, toggleChecklist } = useDossier();
  const isInternal = state.viewMode === 'internal';
  const seg = [...DATA.SEG_PROFILES].sort((a, b) => b.risk_mean - a.risk_mean);

  const checklistItems = [
    'Data refresh scheduled (weekly)',
    'Feature QA: missingness + outliers checked',
    'Risk thresholds documented',
    'Segment proportions monitored',
    'Alerting rules defined (high risk + rising gaps)',
    'Client dashboard snapshot exported',
    'Survey integration validated',
  ];

  return (
    <PanelCard id="deployment">
      <SectionHeader
        id="deployment-header"
        title="Deployment Plan"
        subtitle="Player intelligence cards, NBA rules, monitoring logic, and responsible-use boundary."
        whyItMatters="Analytics without deployment is insight without impact."
        badge="Layer 3"
        stepId="deployment"
        nextStepId="verdict"
      />

      {/* Cross-view player intelligence cards — HERO */}
      <div className="mt-3 mb-4">
        <h3 className="text-xs font-black text-primary mb-3">Player Intelligence Cards — Cross-View (Hero Deliverable)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {DATA.CROSS_VIEW_ARCHETYPES.map(card => (
            <div key={card.card_name} className="glass-panel p-4 border-l-4 border-l-primary/70 hover:border-l-primary transition-colors">
              <h4 className="text-sm font-black text-foreground">{card.card_name}</h4>
              <p className="text-[10px] text-muted-foreground/60 mt-0.5 mb-2">Cross-view archetype</p>
              <p className="text-xs text-muted-foreground leading-relaxed mb-3">{card.core_story}</p>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div><span className="text-primary font-bold">Risk:</span> <span className="text-foreground/80">{card.main_risk}</span></div>
                <div><span className="text-ok font-bold">Action:</span> <span className="text-foreground/80">{card.action_family}</span></div>
                <div><span className="text-muted-foreground">Behavior:</span> <span className="text-foreground/80">{card.behavior_anchor}</span></div>
                <div><span className="text-muted-foreground">Survey:</span> <span className="text-foreground/80">{card.survey_anchor}</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Segment risk bar chart */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div style={{ height: 320 }}>
          <PlotlyChart data={[{
            x: seg.map(s => DATA.SEG_LABELS[String(s.seg_hybrid)]),
            y: seg.map(s => s.risk_mean), type: 'bar',
            marker: { color: 'hsla(0,80%,58%,0.75)' },
          }]} layout={{ xaxis: { tickangle: -15 }, yaxis: { title: 'risk mean' }, margin: { t: 10, b: 80, l: 55, r: 10 } }} />
        </div>
        <div style={{ height: 320 }}>
          {/* Monitoring flow */}
          <PlotlyChart data={[{
            x: ['Ingest', 'Feature build', 'Score', 'Update dashboard', 'Monitor drift', 'Trigger actions'],
            y: [1, 2, 3, 4, 5, 6], type: 'scatter', mode: 'lines+markers',
            line: { color: 'hsla(0,80%,58%,0.95)' }, marker: { size: 8 },
          }]} layout={{ xaxis: { tickangle: -15 }, yaxis: { visible: false }, margin: { t: 10, b: 70, l: 20, r: 10 } }} />
        </div>
      </div>

      {/* NBA Rules Table */}
      <div className="mt-4">
        <h3 className="text-xs font-black text-primary mb-2">NBA Recommendation Rules</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-muted-foreground">
            <thead>
              <tr className="border-b border-primary/20">
                <th className="text-left p-2 font-bold text-foreground">Segment</th>
                <th className="text-left p-2">Objective</th>
                <th className="text-left p-2">Tone</th>
                <th className="text-left p-2">Action</th>
                <th className="text-left p-2">Pressure</th>
                <th className="text-left p-2">Risk</th>
              </tr>
            </thead>
            <tbody>
              {DATA.NBA_RULES.map(r => (
                <tr key={r.survey_segment} className="border-b border-primary/10 hover:bg-primary/5">
                  <td className="p-2 font-semibold text-foreground">{r.survey_segment}</td>
                  <td className="p-2">{r.objective}</td>
                  <td className="p-2">{r.message_tone}</td>
                  <td className="p-2">{r.recommended_action}</td>
                  <td className="p-2">{r.contact_pressure}</td>
                  <td className="p-2"><span className={r.risk_level === 'High' ? 'text-primary font-bold' : r.risk_level === 'Low' ? 'text-ok' : 'text-warn'}>{r.risk_level}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Responsible use */}
      <div className="glass-panel p-3 mt-4 border border-warn/20">
        <h4 className="text-xs font-black text-warn mb-1">Responsible Use Boundary</h4>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          This is a <strong>decision-support prototype</strong>, not an automated targeting engine. 
          Fatigue or disengagement should never be used as a trigger for manipulative monetization pressure. 
          The framework emphasizes relevance, reduced overload, and respectful communication.
        </p>
      </div>

      {/* Interactive checklist */}
      <div className="glass-panel p-3 mt-3">
        <h4 className="text-xs font-black text-primary mb-2">Release Checklist (interactive)</h4>
        <div className="space-y-2">
          {checklistItems.map((item, i) => {
            const k = `c${i}`;
            return (
              <label key={k} className="flex items-start gap-2 cursor-pointer text-xs text-muted-foreground hover:text-foreground transition-colors">
                <input
                  type="checkbox"
                  checked={!!state.checklist[k]}
                  onChange={() => {
                    toggleChecklist(k);
                    toast({ title: "Checklist updated", description: state.checklist[k] ? "Item unchecked" : "Item marked complete" });
                  }}
                  className="mt-0.5 accent-primary"
                />
                <span>{item}</span>
              </label>
            );
          })}
        </div>
      </div>
    </PanelCard>
  );
}
