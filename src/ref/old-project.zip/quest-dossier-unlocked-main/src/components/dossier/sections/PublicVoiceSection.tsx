import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';

export function PublicVoiceSection() {
  const t = DATA.TOPIC_RANK;
  const A = DATA.ACCOUNTS;

  return (
    <PanelCard id="voice">
      <SectionHeader
        id="voice-header"
        title="Public Voice"
        subtitle="Topic pressure identifies high-visibility player concerns from public reviews."
        whyItMatters="Public voice reveals what players complain about most loudly, guiding communication priorities."
        badge="Layer 2"
        stepId="voice"
        nextStepId="crossview"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 360 }}>
          <PlotlyChart data={[{
            x: t.map(d => d.share), y: t.map(d => d.neg_rate),
            mode: 'markers+text', text: t.map(d => d.label.split('(')[1]?.replace(')', '') || d.label),
            textposition: 'top center', textfont: { size: 9 },
            marker: { size: t.map(d => Math.max(12, d.pressure * 200000)), opacity: 0.75, color: 'hsla(0,80%,58%,0.7)' },
          }]} layout={{ xaxis: { title: 'share' }, yaxis: { title: 'negative rate' }, margin: { t: 10, b: 45, l: 50, r: 10 } }} />
        </div>
        <div style={{ height: 360 }}>
          <PlotlyChart data={[{
            type: 'table',
            header: {
              values: ['Topic', 'Pressure', 'Share', 'NegRate', 'AvgSent', 'n'],
              fill: { color: 'hsla(216,40%,8%,0.7)' },
              font: { color: '#9aa4b2', size: 10 }, align: 'left',
            },
            cells: {
              values: [
                t.map(d => d.label), t.map(d => d.pressure.toFixed(4)),
                t.map(d => d.share.toFixed(3)), t.map(d => d.neg_rate.toFixed(3)),
                t.map(d => d.avg_sent.toFixed(3)), t.map(d => d.n),
              ],
              fill: { color: 'hsla(216,40%,8%,0.4)' },
              font: { color: '#e6edf3', size: 10 }, align: 'left',
            },
          }]} layout={{ margin: { t: 5, b: 5, l: 5, r: 5 } }} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 280 }}>
          <PlotlyChart data={[{
            x: t.map(d => d.label), y: t.map(d => d.pressure), type: 'bar',
            marker: { color: 'hsla(0,80%,58%,0.75)' },
          }]} layout={{ xaxis: { tickangle: -15 }, yaxis: { title: 'pressure' }, margin: { t: 10, b: 80, l: 50, r: 10 } }} />
        </div>
        <div style={{ height: 280 }}>
          <PlotlyChart data={[{
            x: A.map(d => d.top_topic_pressure), y: A.map(d => d.risk_score ?? 0),
            mode: 'markers', marker: { size: 6, opacity: 0.8, color: A.map(d => d.seg_hybrid), colorscale: 'Reds' },
          }]} layout={{ xaxis: { title: 'top_topic_pressure' }, yaxis: { title: 'risk_score' }, margin: { t: 10, b: 45, l: 55, r: 10 } }} />
        </div>
      </div>
    </PanelCard>
  );
}
