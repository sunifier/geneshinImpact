import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';

export function ForensicsLabSection() {
  const A = DATA.ACCOUNTS;
  const seg = DATA.SEG_PROFILES;

  return (
    <PanelCard id="forensics">
      <SectionHeader
        id="forensics-header"
        title="Forensics Lab"
        subtitle="Feature distributions and quality checks. Output: clean behavioral fingerprints for segmentation."
        whyItMatters="Artifacts in distributions would invalidate downstream segments and risk scores."
        badge="Phase 3"
        stepId="forensics"
        nextStepId="segments"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 300 }}>
          <PlotlyChart
            data={[{ x: A.map(d => d.max_gap_days), type: 'histogram', nbinsx: 25, marker: { color: 'hsla(0,80%,58%,0.75)' } }]}
            layout={{ xaxis: { title: 'max_gap_days' }, yaxis: { title: 'count' } }}
          />
        </div>
        <div style={{ height: 300 }}>
          <PlotlyChart
            data={[{ x: A.map(d => d.pulls_per_day), type: 'histogram', nbinsx: 28, marker: { color: 'hsla(0,70%,50%,0.65)' } }]}
            layout={{ xaxis: { title: 'pulls_per_day' }, yaxis: { title: 'count' } }}
          />
        </div>
      </div>
      <div style={{ height: 280 }} className="mt-3">
        <PlotlyChart
          data={[{
            type: 'pie',
            labels: seg.map(s => DATA.SEG_LABELS[String(s.seg_hybrid)]),
            values: seg.map(s => s.n),
            hole: 0.55,
            marker: { colors: ['hsla(0,80%,58%,0.7)', 'hsla(0,70%,50%,0.6)', 'hsla(0,60%,45%,0.5)', 'hsla(0,90%,40%,0.8)'] },
          }]}
          layout={{ margin: { t: 5, b: 5, l: 5, r: 5 }, showlegend: true, legend: { orientation: 'h', font: { size: 10 } } }}
        />
      </div>
    </PanelCard>
  );
}
