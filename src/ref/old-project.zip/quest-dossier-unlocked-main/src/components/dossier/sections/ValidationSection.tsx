import React, { useState } from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';
import { toast } from '@/hooks/use-toast';

export function ValidationSection() {
  const tests = DATA.TESTS;
  const [bootSeg, setBootSeg] = useState('0');
  const [bootData, setBootData] = useState<number[] | null>(null);

  const runBootstrap = () => {
    const arr = DATA.SEG_RISK_ARRAYS[bootSeg] || [];
    if (arr.length < 5) { toast({ title: "Error", description: "Not enough data" }); return; }
    const B = 800;
    const means: number[] = [];
    for (let b = 0; b < B; b++) {
      let s = 0;
      for (let i = 0; i < arr.length; i++) {
        s += arr[Math.floor(Math.random() * arr.length)];
      }
      means.push(s / arr.length);
    }
    means.sort((a, b) => a - b);
    setBootData(means);
    const p05 = means[Math.floor(0.05 * means.length)];
    const p95 = means[Math.floor(0.95 * means.length)];
    toast({ title: "Bootstrap complete", description: `90% CI: [${p05.toFixed(2)}, ${p95.toFixed(2)}]` });
  };

  return (
    <PanelCard id="validation">
      <SectionHeader
        id="validation-header"
        title="Validation (Internal)"
        subtitle="Statistical testing and bootstrap stability evidence."
        whyItMatters="Without validation, segment differences could be artifacts of noise."
        badge="Internal"
        stepId="validation"
        internalOnly
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 300 }}>
          <PlotlyChart data={[{
            x: tests.map(d => d.metric), y: tests.map(d => -Math.log10(d.p)), type: 'bar',
            marker: { color: 'hsla(0,80%,58%,0.78)' },
          }]} layout={{ xaxis: { tickangle: -20 }, yaxis: { title: '-log10(p)' }, margin: { t: 10, b: 100, l: 55, r: 10 } }} />
        </div>
        <div style={{ height: 300 }}>
          <PlotlyChart data={[{
            z: DATA.P_RISK_MAT,
            x: DATA.SEG_KEYS.map(k => DATA.SEG_LABELS[String(k)]),
            y: DATA.SEG_KEYS.map(k => DATA.SEG_LABELS[String(k)]),
            type: 'heatmap', colorscale: 'Reds', zmin: 0, zmax: 1,
          }]} layout={{ margin: { t: 10, b: 80, l: 80, r: 10 } }} />
        </div>
      </div>

      {/* Bootstrap */}
      <div className="glass-panel p-3 mt-3">
        <h4 className="text-xs font-black text-primary mb-2">Bootstrap Simulator</h4>
        <p className="text-[10px] text-muted-foreground mb-3">
          Select a segment and run bootstrap of the risk mean. This demonstrates stability of the mean estimate.
        </p>
        <div className="flex gap-3 items-center flex-wrap mb-3">
          <select value={bootSeg} onChange={e => setBootSeg(e.target.value)}
            className="px-3 py-1.5 rounded-lg text-xs border border-primary/25 bg-background text-foreground">
            {DATA.SEG_KEYS.map(k => (
              <option key={k} value={String(k)}>{DATA.SEG_LABELS[String(k)]}</option>
            ))}
          </select>
          <button onClick={runBootstrap}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-primary text-primary-foreground hover:brightness-105 transition-all">
            Run bootstrap
          </button>
          {bootData && <span className="text-[10px] text-muted-foreground">Samples: {bootData.length}</span>}
        </div>
        {bootData && (
          <div style={{ height: 280 }}>
            <PlotlyChart data={[
              { x: bootData, type: 'histogram', nbinsx: 30, marker: { color: 'hsla(0,80%,58%,0.75)' }, name: 'bootstrap means' },
              {
                x: [bootData[Math.floor(0.05 * bootData.length)], bootData[Math.floor(0.95 * bootData.length)]],
                y: [0, 0], mode: 'markers',
                marker: { size: 12, color: 'hsla(150,65%,50%,0.95)' }, name: 'p05/p95',
              },
            ]} layout={{ xaxis: { title: 'bootstrapped risk mean' }, yaxis: { title: 'count' }, showlegend: true }} />
          </div>
        )}
      </div>
    </PanelCard>
  );
}
