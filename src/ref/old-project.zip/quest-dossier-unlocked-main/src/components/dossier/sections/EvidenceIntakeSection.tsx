import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';
import { useDossier } from '@/context/DossierContext';

export function EvidenceIntakeSection() {
  const { state } = useDossier();
  const A = DATA.ACCOUNTS;

  const splomData = [{
    type: 'splom' as const,
    dimensions: [
      { label: 'pulls/day', values: A.map(d => d.pulls_per_day) },
      { label: 'max_gap', values: A.map(d => d.max_gap_days) },
      { label: 'five_rate', values: A.map(d => d.five_rate) },
      { label: 'banner_div', values: A.map(d => d.banner_diversity) },
    ],
    marker: { size: 4, opacity: 0.7, color: A.map(d => d.seg_hybrid), colorscale: 'Reds' },
  }];

  const voiceScatter = [{
    x: A.map(d => d.mean_topic_pressure),
    y: A.map(d => d.risk_score ?? 0),
    mode: 'markers' as const,
    marker: { size: 6, opacity: 0.8, color: A.map(d => d.global_neg_rate), colorscale: 'Reds', colorbar: { title: 'neg_rate', len: 0.5 } },
    hovertemplate: 'pressure=%{x:.4f}<br>risk=%{y:.1f}<extra></extra>',
  }];

  return (
    <PanelCard id="intake">
      <SectionHeader
        id="intake-header"
        title="Evidence Intake"
        subtitle="Sources integrated: account telemetry, public voice topic pressure, and survey responses."
        whyItMatters="Data quality and coverage determine what conclusions the project can support."
        badge="Phase 2"
        stepId="intake"
        nextStepId="forensics"
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
        <div className="glass-panel p-3">
          <h3 className="text-xs font-black text-primary mb-1">Behavioral Telemetry</h3>
          <p className="text-[11px] text-muted-foreground">{DATA.N_ACCOUNTS} accounts with engagement intensity, inactivity gaps, banner diversity, rarity rates, and derived segment labels.</p>
        </div>
        <div className="glass-panel p-3">
          <h3 className="text-xs font-black text-primary mb-1">Public Voice</h3>
          <p className="text-[11px] text-muted-foreground">Topic-level pressure table (share × negative rate × volume proxy). Used for prioritizing pain points at aggregate level.</p>
        </div>
        <div className="glass-panel p-3">
          <h3 className="text-xs font-black text-primary flex items-center gap-2 mb-1">
            Survey Layer
            <span className="inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold border border-ok/40 text-ok">collected</span>
          </h3>
          <p className="text-[11px] text-muted-foreground">{DATA.N_SURVEY} respondents. Motivation, break likelihood, disengagement risk, spending profile, communication preferences.</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 380 }}>
          <PlotlyChart data={splomData} layout={{ margin: { t: 10, b: 40, l: 40, r: 10 } }} />
        </div>
        <div style={{ height: 380 }}>
          <PlotlyChart data={voiceScatter} layout={{
            margin: { t: 10, b: 40, l: 50, r: 10 },
            xaxis: { title: 'mean_topic_pressure' },
            yaxis: { title: 'risk_score' },
          }} />
        </div>
      </div>
      <p className="text-[10px] text-muted-foreground/60 mt-2 italic">Right chart links risk to public-voice indicators. Note: public voice data is available at aggregate level only, not per player.</p>
    </PanelCard>
  );
}
