import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';
import { useDossier } from '@/context/DossierContext';

export function FinalVerdictSection() {
  const { state } = useDossier();
  const isInternal = state.viewMode === 'internal';
  const c = DATA.CONCLUSION;
  const seg = [...DATA.SEG_PROFILES].sort((a, b) => b.risk_mean - a.risk_mean);
  const imp = DATA.IMPORTANCE;

  return (
    <PanelCard id="verdict">
      <SectionHeader
        id="verdict-header"
        title="Final Verdict"
        subtitle="Retained conclusions and what to do next."
        whyItMatters="This is the executive summary — every prior section leads here."
        badge="Verdict"
        stepId="verdict"
      />

      {/* Conclusion panel */}
      <div className="glass-panel p-4 mt-3 border-l-4 border-l-primary">
        <h3 className="text-sm font-black text-primary mb-2">Conclusion</h3>
        <div className="space-y-1 text-xs text-muted-foreground">
          <p><strong className="text-foreground">Highest-risk segment:</strong> {c.highest_risk_segment}</p>
          <p><strong className="text-foreground">Top risk-aligned drivers:</strong> {c.top_drivers.join(', ')}</p>
          <p><strong className="text-foreground">Highest-pressure topics:</strong> {c.top_topics.join(', ')}</p>
        </div>
      </div>

      {/* What we retained / rejected */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
        <div className="glass-panel p-3">
          <h4 className="text-xs font-black text-ok mb-2">What We Retained</h4>
          <ul className="text-[10px] text-muted-foreground space-y-1">
            <li>✓ Behavior segmentation (4 clusters, bootstrap-stable)</li>
            <li>✓ Survey segmentation (6 clusters from 42 respondents)</li>
            <li>✓ Cross-view synthesis (4 archetypes)</li>
            <li>✓ NBA layer with communication recommendations</li>
            <li>✓ Risk prioritization driven by inactivity gaps</li>
          </ul>
        </div>
        <div className="glass-panel p-3">
          <h4 className="text-xs font-black text-primary mb-2">What We Rejected or Demoted</h4>
          <ul className="text-[10px] text-muted-foreground space-y-1">
            <li>✗ Public voice + behavior direct fusion (no player-level linkage)</li>
            <li>⚠ Synthetic hybrid mapping (demo only, non-inferential)</li>
            <li>— H4 (player-level fusion) remains not testable</li>
            <li>~ H5 (public voice correlation) exploratory only</li>
          </ul>
        </div>
      </div>

      {/* Core archetypes */}
      <div className="mt-4">
        <h4 className="text-xs font-black text-primary mb-2">Core Player Archetypes</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {DATA.CROSS_VIEW_ARCHETYPES.map(a => (
            <div key={a.card_name} className="glass-panel p-2 text-center">
              <p className="text-[10px] font-bold text-foreground">{a.card_name}</p>
              <p className="text-[9px] text-muted-foreground">{a.action_family}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
        <div style={{ height: 320 }}>
          <PlotlyChart data={[{
            x: seg.map(s => DATA.SEG_LABELS[String(s.seg_hybrid)]),
            y: seg.map(s => s.risk_mean), type: 'bar',
            error_y: {
              type: 'data', symmetric: false,
              array: seg.map(s => s.risk_ci_high - s.risk_mean),
              arrayminus: seg.map(s => s.risk_mean - s.risk_ci_low),
            },
            marker: { color: 'hsla(0,80%,58%,0.75)' },
          }]} layout={{ xaxis: { tickangle: -15 }, yaxis: { title: 'risk mean (95% CI)' }, margin: { t: 10, b: 80, l: 60, r: 10 } }} />
        </div>
        <div style={{ height: 320 }}>
          <PlotlyChart data={[{
            x: imp.map(d => d.feature), y: imp.map(d => d.abs_corr), type: 'bar',
            marker: { color: 'hsla(0,80%,58%,0.78)' },
          }]} layout={{ xaxis: { tickangle: -20 }, yaxis: { title: '|corr with risk|' }, margin: { t: 10, b: 100, l: 55, r: 10 } }} />
        </div>
      </div>

      {/* What to do next */}
      <div className="glass-panel p-3 mt-4">
        <h4 className="text-xs font-black text-primary mb-2">What To Do Next</h4>
        <ul className="text-[10px] text-muted-foreground space-y-1">
          <li>1. Deploy behavior segmentation as the primary risk-triaging layer</li>
          <li>2. Use survey profiles to inform communication tone and frequency</li>
          <li>3. Operationalize NBA rules through CRM or in-game messaging pipelines</li>
          <li>4. Schedule weekly data refresh and monitor segment drift</li>
          <li>5. Plan linked survey round (with account IDs) to enable H4 testing</li>
        </ul>
      </div>

      {isInternal && (
        <div className="glass-panel p-3 mt-3">
          <h4 className="text-xs font-black text-primary mb-2">Future Data Needed</h4>
          <ul className="text-[10px] text-muted-foreground space-y-1">
            <li>• Linked survey with account IDs for player-level fusion (H4)</li>
            <li>• Longitudinal behavioral panel for temporal risk dynamics</li>
            <li>• A/B testing infrastructure for NBA rule evaluation</li>
            <li>• Revenue/LTV data for commercial risk quantification</li>
          </ul>
        </div>
      )}

      {/* Hypothesis audit */}
      <div className="glass-panel p-3 mt-3">
        <h4 className="text-xs font-black text-primary mb-2">Hypothesis Audit</h4>
        <div className="space-y-1.5">
          {DATA.HYPOTHESES.map(h => (
            <div key={h.id} className="flex items-start gap-2 text-[10px]">
              <span className={`font-bold shrink-0 w-6 ${
                h.status.includes('Supported') ? 'text-ok' :
                h.status.includes('Not testable') ? 'text-muted-foreground' : 'text-warn'
              }`}>{h.id}</span>
              <span className="text-foreground/80">{h.statement}</span>
              <span className={`ml-auto shrink-0 px-1.5 py-0.5 rounded-full border text-[8px] font-bold ${
                h.status.includes('Supported') ? 'border-ok/30 text-ok' :
                h.status.includes('Not testable') ? 'border-muted-foreground/30 text-muted-foreground' : 'border-warn/30 text-warn'
              }`}>{h.status}</span>
            </div>
          ))}
        </div>
      </div>
    </PanelCard>
  );
}
