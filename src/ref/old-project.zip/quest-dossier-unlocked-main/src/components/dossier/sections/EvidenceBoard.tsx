import React, { useRef, useEffect, useCallback, useState } from 'react';
import { useDossier, STEPS, INTERNAL_STEPS } from '@/context/DossierContext';

interface NodeData {
  id: string;
  label: string;
  subtitle: string;
  x: number;
  y: number;
  internalOnly?: boolean;
}

const DEFAULT_NODES: NodeData[] = [
  { id: 'brief', label: 'Case Brief', subtitle: 'Business Understanding', x: 40, y: 60 },
  { id: 'intake', label: 'Evidence Intake', subtitle: 'Data Understanding', x: 230, y: 170 },
  { id: 'forensics', label: 'Forensics Lab', subtitle: 'Data Prep', x: 70, y: 310 },
  { id: 'segments', label: 'Segmentation Room', subtitle: 'Modeling', x: 480, y: 90 },
  { id: 'risk', label: 'Risk Engine', subtitle: 'Evaluation', x: 480, y: 260 },
  { id: 'voice', label: 'Public Voice', subtitle: 'Insights Layer', x: 300, y: 370 },
  { id: 'crossview', label: 'Cross-View', subtitle: 'Synthesis', x: 680, y: 160 },
  { id: 'deployment', label: 'Deployment Plan', subtitle: 'Operationalization', x: 780, y: 280 },
  { id: 'verdict', label: 'Final Verdict', subtitle: 'Conclusion', x: 820, y: 60 },
  { id: 'validation', label: 'Validation', subtitle: 'Stat tests', x: 780, y: 370, internalOnly: true },
  { id: 'diagnostics', label: 'Diagnostics', subtitle: 'Correlation', x: 780, y: 420, internalOnly: true },
];

const LINKS = [
  ['brief', 'intake'], ['intake', 'forensics'], ['forensics', 'segments'],
  ['segments', 'risk'], ['risk', 'voice'], ['voice', 'crossview'],
  ['crossview', 'deployment'], ['deployment', 'verdict'],
];
const INTERNAL_LINKS = [['risk', 'validation'], ['validation', 'diagnostics']];

export function EvidenceBoard() {
  const { state } = useDossier();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const [nodes, setNodes] = useState(DEFAULT_NODES);
  const [dragging, setDragging] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const visibleNodes = state.viewMode === 'internal' ? nodes : nodes.filter(n => !n.internalOnly);
  const links = state.viewMode === 'internal' ? [...LINKS, ...INTERNAL_LINKS] : LINKS;

  const drawStrings = useCallback(() => {
    const canvas = canvasRef.current;
    const board = boardRef.current;
    if (!canvas || !board) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    canvas.width = board.clientWidth;
    canvas.height = board.clientHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const nodeMap: Record<string, NodeData> = {};
    visibleNodes.forEach(n => { nodeMap[n.id] = n; });

    ctx.lineWidth = 2.2;

    links.forEach(([aKey, bKey]) => {
      const a = nodeMap[aKey], b = nodeMap[bKey];
      if (!a || !b) return;
      
      const ax = a.x + 75, ay = a.y + 25;
      const bx = b.x + 75, by = b.y + 25;

      const glow = state.done[aKey] && state.done[bKey];
      ctx.strokeStyle = glow ? 'hsla(150,65%,50%,0.75)' : 'hsla(0,80%,58%,0.65)';
      ctx.shadowColor = glow ? 'hsla(150,65%,50%,0.45)' : 'hsla(0,80%,58%,0.25)';
      ctx.shadowBlur = glow ? 10 : 6;

      ctx.beginPath();
      ctx.moveTo(ax, ay);
      const mx = (ax + bx) / 2;
      const my = (ay + by) / 2 - 30;
      ctx.quadraticCurveTo(mx, my, bx, by);
      ctx.stroke();
      ctx.shadowBlur = 0;
    });
  }, [visibleNodes, links, state.done]);

  useEffect(() => { drawStrings(); }, [drawStrings]);
  useEffect(() => { window.addEventListener('resize', drawStrings); return () => window.removeEventListener('resize', drawStrings); }, [drawStrings]);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handlePointerDown = (e: React.PointerEvent, nodeId: string) => {
    const target = e.currentTarget as HTMLElement;
    setDragging(nodeId);
    setDragOffset({
      x: e.clientX - target.getBoundingClientRect().left,
      y: e.clientY - target.getBoundingClientRect().top,
    });
    target.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragging || !boardRef.current) return;
    const br = boardRef.current.getBoundingClientRect();
    const x = Math.max(10, Math.min(br.width - 180, e.clientX - br.left - dragOffset.x));
    const y = Math.max(10, Math.min(br.height - 60, e.clientY - br.top - dragOffset.y));
    setNodes(prev => prev.map(n => n.id === dragging ? { ...n, x, y } : n));
    requestAnimationFrame(drawStrings);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (dragging) {
      (e.currentTarget as HTMLElement).releasePointerCapture?.(e.pointerId);
      setDragging(null);
    }
  };

  const autoLayout = () => {
    setNodes(DEFAULT_NODES);
    setTimeout(drawStrings, 50);
  };

  return (
    <section id="board" className="glass-panel p-4 mb-4">
      <div className="flex justify-between items-start gap-3 flex-wrap mb-3">
        <div>
          <h2 className="text-lg font-black text-primary tracking-wide">Evidence Board</h2>
          <p className="text-xs text-muted-foreground">Drag nodes to rearrange. Click to jump to section. Red strings follow the investigation logic.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={autoLayout}
            className="px-3 py-1.5 rounded-lg text-xs font-bold border border-primary/25 text-foreground hover:bg-primary/10 transition-all">
            Auto-layout
          </button>
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="px-3 py-1.5 rounded-lg text-xs font-bold border border-primary/25 text-foreground hover:bg-primary/10 transition-all">
            Top
          </button>
        </div>
      </div>

      <div ref={boardRef} className="relative rounded-xl border border-primary/30 overflow-hidden"
        style={{ height: 480, background: 'linear-gradient(180deg, hsl(216,35%,10%), hsl(216,50%,5%))' }}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}>
        <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />
        
        {visibleNodes.map(node => (
          <div
            key={node.id}
            className={`evidence-node ${state.done[node.id] ? 'done' : ''}`}
            style={{ left: node.x, top: node.y }}
            onPointerDown={e => handlePointerDown(e, node.id)}
            onClick={() => !dragging && scrollTo(node.id)}
          >
            <div className="font-extrabold text-foreground text-xs">{node.label}</div>
            <div className="flex justify-between gap-2 mt-1 text-[10px]">
              <span className="text-muted-foreground">{node.subtitle}</span>
              <span className={state.done[node.id] ? 'text-ok' : 'text-warn'}>
                {state.done[node.id] ? 'logged' : 'pending'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
