import React, { useState, useMemo } from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';
import { useDossier } from '@/context/DossierContext';

export function SegmentationRoomSection() {
  const { state } = useDossier();
  const isInternal = state.viewMode === 'internal';
  const [selectedSeg, setSelectedSeg] = useState('0');
  const A = DATA.ACCOUNTS;
  const segProfiles = DATA.SEG_PROFILES;

  // Radar for selected segment
  const radarData = useMemo(() => {
    const s = segProfiles.find(p => String(p.seg_hybrid) === selectedSeg);
    if (!s) return [];
    const keys = ['mean_pulls_per_day', 'mean_max_gap_days', 'mean_five_rate', 'mean_banner_diversity'] as const;
    const nice = ['Intensity', 'Inactivity gap', '5-star rate', 'Banner diversity'];
    const vals = keys.map((k, i) => {
      const mn = Math.min(...segProfiles.map(z => z[k]));
      const mx = Math.max(...segProfiles.map(z => z[k]));
      return mx - mn < 1e-9 ? 0.5 : (s[k] - mn) / (mx - mn);
    });
    return [{
      type: 'scatterpolar' as const,
      r: [...vals, vals[0]],
      theta: [...nice, nice[0]],
      fill: 'toself' as const,
      line: { color: 'hsla(0,80%,58%,0.95)' },
      fillcolor: 'hsla(0,80%,58%,0.28)',
    }];
  }, [selectedSeg, segProfiles]);

  // Violin of risk by segment
  const violinData = useMemo(() => {
    return segProfiles.map(s => ({
      type: 'violin' as const,
      y: A.filter(a => a.seg_hybrid === s.seg_hybrid).map(a => a.risk_score ?? 0),
      name: DATA.SEG_LABELS[String(s.seg_hybrid)],
      box: { visible: true },
      meanline: { visible: true },
      fillcolor: 'hsla(0,80%,58%,0.35)',
      line: { color: 'hsla(0,80%,58%,0.85)' },
      opacity: 0.9,
    }));
  }, [A, segProfiles]);

  // Box plots for key features
  const boxData = useMemo(() => {
    const features = ['pulls_per_day', 'max_gap_days', 'five_rate', 'banner_diversity'] as const;
    return features.flatMap(f =>
      segProfiles.map(s => ({
        type: 'box' as const,
        y: A.filter(a => a.seg_hybrid === s.seg_hybrid).map(a => a[f] ?? 0),
        name: `${f} — ${DATA.SEG_LABELS[String(s.seg_hybrid)]?.split(' ')[0]}`,
        marker: { color: 'hsla(0,80%,58%,0.55)' },
        boxpoints: false as const,
      }))
    );
  }, [A, segProfiles]);

  const selectTopRisk = () => {
    const top = [...segProfiles].sort((a, b) => b.risk_mean - a.risk_mean)[0];
    if (top) setSelectedSeg(String(top.seg_hybrid));
  };

  return (
    <PanelCard id="segments">
      <SectionHeader
        id="segments-header"
        title="Segmentation Room"
        subtitle="Retained behavioral segmentation: 4 clusters from K-Means on engagement features."
        whyItMatters="Segments define who the players are and how their risk profiles differ."
        badge="Phase 4"
        stepId="segments"
        nextStepId="risk"
      />

      <div className="flex gap-3 flex-wrap items-center mt-2 mb-3">
        <select value={selectedSeg} onChange={e => setSelectedSeg(e.target.value)}
          className="px-3 py-1.5 rounded-lg text-xs border border-primary/25 bg-background text-foreground">
          {segProfiles.map(s => (
            <option key={s.seg_hybrid} value={String(s.seg_hybrid)}>
              {DATA.SEG_LABELS[String(s.seg_hybrid)]} (n={s.n})
            </option>
          ))}
        </select>
        <button onClick={selectTopRisk}
          className="px-3 py-1.5 rounded-lg text-xs font-bold border border-primary/25 text-foreground hover:bg-primary/10 transition-all">
          Highest-risk segment
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div style={{ height: 320 }}>
          <PlotlyChart data={radarData} layout={{
            margin: { t: 10, b: 10, l: 30, r: 30 },
            polar: { bgcolor: 'rgba(0,0,0,0)', radialaxis: { visible: true, range: [0, 1] } },
          }} />
        </div>
        <div style={{ height: 320 }}>
          <PlotlyChart data={violinData} layout={{
            margin: { t: 10, b: 70, l: 50, r: 10 },
            yaxis: { title: 'risk_score' },
          }} />
        </div>
      </div>

      {isInternal && (
        <div style={{ height: 380 }} className="mt-3">
          <PlotlyChart data={boxData} layout={{
            margin: { t: 10, b: 120, l: 60, r: 10 },
            showlegend: false,
          }} />
        </div>
      )}

      {/* Behavior segment cards */}
      <div className="mt-4">
        <h3 className="text-xs font-black text-primary mb-2">Behavior Segment Profiles</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {DATA.BEHAVIOR_CARDS.map(card => (
            <div key={card.segment_name} className="glass-panel p-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-foreground">{card.segment_name}</span>
                <span className="text-[9px] text-muted-foreground">({card.share_pct}%)</span>
              </div>
              <p className="text-[10px] text-muted-foreground leading-relaxed">{card.signature}</p>
              {isInternal && (
                <>
                  <p className="text-[10px] text-warn mt-1">Risk: {card.main_risk}</p>
                  <p className="text-[10px] text-muted-foreground/70 mt-0.5">{card.interpretation}</p>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </PanelCard>
  );
}
