import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { DATA } from '@/data/dossierData';
import { useDossier } from '@/context/DossierContext';

export function CrossViewMeaningSection() {
  const { state } = useDossier();
  const isInternal = state.viewMode === 'internal';

  return (
    <PanelCard id="crossview">
      <SectionHeader
        id="crossview-header"
        title="Cross-View Meaning"
        subtitle="How retained behavioral and survey views connect — the conceptual synthesis."
        whyItMatters="Cross-view alignment validates whether different data lenses tell a coherent story about the same players."
        badge="Synthesis"
        stepId="crossview"
        nextStepId="deployment"
      />

      {/* Retained vs Demo hierarchy */}
      <div className="glass-panel p-3 mt-3 mb-4">
        <div className="flex items-center gap-2 mb-2">
          <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-ok/40 text-ok">RETAINED</span>
          <span className="text-xs text-foreground font-medium">Cross-view synthesis (conceptual archetype alignment)</span>
        </div>
        <p className="text-[10px] text-muted-foreground mb-3">
          The four archetypes below were derived by mapping behavioral segment signatures to survey segment profiles. 
          This is a conceptual correspondence — not a player-level fusion.
        </p>
        
        {/* Cross-view archetype cards — HERO deliverable */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {DATA.CROSS_VIEW_ARCHETYPES.map(card => (
            <div key={card.card_name} className="glass-panel p-4 border-l-2 border-l-primary/50">
              <h4 className="text-sm font-bold text-foreground mb-1">{card.card_name}</h4>
              <p className="text-[10px] text-muted-foreground leading-relaxed mb-2">{card.core_story}</p>
              <div className="space-y-1">
                <div className="flex items-start gap-2">
                  <span className="text-[9px] text-primary font-bold shrink-0">BEHAVIOR</span>
                  <span className="text-[10px] text-foreground/80">{card.behavior_anchor}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] text-primary font-bold shrink-0">SURVEY</span>
                  <span className="text-[10px] text-foreground/80">{card.survey_anchor}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] text-warn font-bold shrink-0">RISK</span>
                  <span className="text-[10px] text-foreground/80">{card.main_risk}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] text-ok font-bold shrink-0">ACTION</span>
                  <span className="text-[10px] text-foreground/80">{card.action_family}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Synthetic hybrid — DEMO ONLY */}
      <div className="glass-panel p-3 border border-warn/20 opacity-70">
        <div className="flex items-center gap-2 mb-2">
          <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-warn/40 text-warn">DEMO ONLY</span>
          <span className="text-xs text-muted-foreground font-medium">Synthetic hybrid mapping (non-inferential)</span>
        </div>
        <p className="text-[10px] text-muted-foreground mb-2">
          These mappings use artificial linkage between behavior and survey segments. They are illustrative only 
          and must not be treated as validated findings. No player-level fusion was possible.
        </p>
        <div className="space-y-1">
          {DATA.SYNTHETIC_HYBRID.map(h => (
            <div key={h.hybrid_label} className="flex items-center gap-3 text-[10px]">
              <span className="text-warn font-bold w-16 shrink-0">{h.hybrid_label}</span>
              <span className="text-muted-foreground">≈ {h.behavior} + {h.survey}</span>
              <span className="inline-flex px-1.5 py-0.5 rounded-full text-[8px] border border-warn/30 text-warn/70">{h.note}</span>
            </div>
          ))}
        </div>
      </div>

      {isInternal && (
        <div className="glass-panel p-3 mt-3">
          <h4 className="text-xs font-black text-primary mb-2">Integration Strategy Evaluation</h4>
          <p className="text-[10px] text-muted-foreground leading-relaxed">
            H4 (player-level fusion improves risk prediction) remains <strong className="text-muted-foreground">not testable</strong> because 
            the behavioral and survey datasets cannot be linked at the individual level. The cross-view synthesis therefore operates 
            at the segment-correspondence level only. This is a structural limitation, not a methodological failure. 
            Future work requiring individual-level fusion would need either survey-embedded account IDs or a panel study design.
          </p>
        </div>
      )}
    </PanelCard>
  );
}
