import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { useDossier } from '@/context/DossierContext';

export function CaseBriefSection() {
  const { state } = useDossier();
  const isInternal = state.viewMode === 'internal';

  return (
    <PanelCard id="brief">
      <SectionHeader
        id="brief-header"
        title="Case Brief"
        subtitle="Business understanding — the key questions this project answers."
        whyItMatters="Without clear questions, segmentation becomes pattern-finding without purpose."
        badge="Phase 1"
        stepId="brief"
        nextStepId="intake"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div className="glass-panel p-3">
          <h3 className="text-xs font-black text-primary mb-2">Key Questions</h3>
          <ol className="text-xs text-muted-foreground space-y-1.5 list-decimal list-inside">
            <li>Which behavioral segments show the highest retention risk signals?</li>
            <li>Which behavior features most strongly align with risk?</li>
            <li>Which public-voice topics show the highest pressure?</li>
            <li>What do players privately report about motivation and disengagement risk?</li>
            <li>How do behavioral and survey views align or diverge?</li>
            <li>Which operational actions should be prioritized by segment?</li>
          </ol>
        </div>
        <div className="glass-panel p-3">
          <h3 className="text-xs font-black text-primary mb-2">Success Criteria</h3>
          <ul className="text-xs text-muted-foreground space-y-1.5">
            <li>✓ Clear segment personas supported by measurable patterns</li>
            <li>✓ Risk signals that separate segments (validated statistically)</li>
            <li>✓ Survey-informed player-state profiles with NBA recommendations</li>
            <li>✓ Cross-view synthesis connecting behavior and private state</li>
            <li>✓ Dashboard-ready deployment loop with monitoring checklist</li>
            {isInternal && <li>✓ Bootstrap stability validation for key segments</li>}
          </ul>
        </div>
      </div>
      {isInternal && (
        <div className="glass-panel p-3 mt-3">
          <h3 className="text-xs font-black text-primary mb-2">Analytical Framework</h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            The project follows CRISP-DM methodology. Four analytical lenses are triangulated: 
            game system incentives (rarity, cadence, monetization context), behavior (gacha activity intensity, gaps, diversity), 
            public voice (review sentiment, topic pressure), and private intel (survey). 
            The final integration strategy evaluates which layers can be retained at the player level and which remain at aggregate level only.
          </p>
        </div>
      )}
    </PanelCard>
  );
}
