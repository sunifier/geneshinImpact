import React from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';

export function DiagnosticsSection() {
  // Correlation heatmap using feature importance correlations
  const features = DATA.IMPORTANCE.map(d => d.feature);
  const corrValues = DATA.IMPORTANCE.map(d => d.corr_with_risk);

  // Build a simple correlation matrix proxy using the data we have
  const z = features.map((_, i) => features.map((_, j) => {
    if (i === j) return 1;
    // Use product of correlations as proxy
    return corrValues[i] * corrValues[j];
  }));

  // Gap diagnostics using P_GAP_MAT
  const segLabels = DATA.SEG_KEYS.map(k => DATA.SEG_LABELS[String(k)]);

  return (
    <PanelCard id="diagnostics">
      <SectionHeader
        id="diagnostics-header"
        title="Diagnostics (Internal)"
        subtitle="Correlation structure and sanity checks for methodological defense."
        whyItMatters="These views help defend the modeling choices in reviews or audits."
        badge="Internal"
        stepId="diagnostics"
        internalOnly
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 360 }}>
          <PlotlyChart data={[{
            z, x: features, y: features,
            type: 'heatmap', colorscale: 'RdBu', zmid: 0,
          }]} layout={{ margin: { t: 10, b: 100, l: 100, r: 10 }, title: { text: 'Feature correlation proxy', font: { size: 11 } } }} />
        </div>
        <div style={{ height: 360 }}>
          <PlotlyChart data={[{
            z: DATA.P_GAP_MAT,
            x: segLabels, y: segLabels,
            type: 'heatmap', colorscale: 'Reds', zmin: 0, zmax: 1,
          }]} layout={{ margin: { t: 10, b: 80, l: 80, r: 10 }, title: { text: 'Gap p-values (pairwise)', font: { size: 11 } } }} />
        </div>
      </div>
    </PanelCard>
  );
}
