import React, { useState, useMemo } from 'react';
import { PanelCard } from '../PanelCard';
import { SectionHeader } from '../SectionHeader';
import { PlotlyChart } from '../PlotlyChart';
import { DATA } from '@/data/dossierData';

export function RiskEngineSection() {
  const A = DATA.ACCOUNTS;
  const [gapVal, setGapVal] = useState(20);
  const [ppdVal, setPpdVal] = useState(10);

  // KNN estimate
  const knnResult = useMemo(() => {
    const K = 15;
    const dists = A.map(d => ({
      dist: Math.pow((d.max_gap_days ?? 0) - gapVal, 2) + Math.pow((d.pulls_per_day ?? 0) - ppdVal, 2),
      risk: d.risk_score ?? 0,
    })).sort((a, b) => a.dist - b.dist).slice(0, K);
    const mean = dists.reduce((s, o) => s + o.risk, 0) / Math.max(1, dists.length);
    return { mean, k: dists.length };
  }, [A, gapVal, ppdVal]);

  // Risk scatter
  const riskScatter = [{
    x: A.map(d => d.pulls_per_day),
    y: A.map(d => d.risk_score ?? 0),
    mode: 'markers' as const,
    marker: { size: 6, opacity: 0.8, color: A.map(d => d.seg_hybrid), colorscale: 'Reds' },
    hovertemplate: 'pulls/day=%{x:.2f}<br>risk=%{y:.1f}<extra></extra>',
  }];

  // Risk trend
  const pts = A.map(d => ({ x: d.max_gap_days, y: d.risk_score ?? 0 })).sort((a, b) => a.x - b.x);
  const bins = 14;
  const minx = Math.min(...pts.map(p => p.x));
  const maxx = Math.max(...pts.map(p => p.x));
  const step = (maxx - minx) / bins;
  const bx: number[] = [], by: number[] = [];
  for (let i = 0; i < bins; i++) {
    const lo = minx + i * step;
    const hi = lo + step;
    const ys = pts.filter(p => p.x >= lo && p.x < hi).map(p => p.y);
    if (ys.length) {
      bx.push((lo + hi) / 2);
      by.push(ys.reduce((a, b) => a + b, 0) / ys.length);
    }
  }

  return (
    <PanelCard id="risk">
      <SectionHeader
        id="risk-header"
        title="Risk Engine"
        subtitle="Account and segment risk prioritization. Use the sandbox to explore behavior neighborhoods."
        whyItMatters="Risk ranking determines which players need attention first and which features drive it."
        badge="Phase 5"
        stepId="risk"
        nextStepId="voice"
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div style={{ height: 340 }}>
          <PlotlyChart data={riskScatter} layout={{
            xaxis: { title: 'pulls_per_day' }, yaxis: { title: 'risk_score' },
          }} />
        </div>
        <div style={{ height: 340 }}>
          <PlotlyChart data={[
            { x: pts.map(p => p.x), y: pts.map(p => p.y), mode: 'markers', name: 'accounts', marker: { size: 5, opacity: 0.3, color: 'hsla(0,80%,58%,0.55)' } },
            { x: bx, y: by, mode: 'lines+markers', name: 'binned mean', line: { color: 'hsla(0,80%,58%,0.95)' }, marker: { size: 6 } },
          ]} layout={{
            xaxis: { title: 'max_gap_days' }, yaxis: { title: 'risk_score' }, showlegend: true, legend: { font: { size: 9 } },
          }} />
        </div>
      </div>

      {/* Sensitivity sandbox */}
      <div className="glass-panel p-4 mt-3">
        <h3 className="text-xs font-black text-primary mb-1">Sensitivity Sandbox (data-driven)</h3>
        <p className="text-[10px] text-muted-foreground mb-3">
          Adjust inputs. The estimate is the average risk of the {knnResult.k} nearest accounts in (max_gap_days, pulls_per_day). 
          <strong className="text-warn"> This is descriptive, not causal.</strong>
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-muted-foreground">max_gap_days: <strong className="text-foreground">{gapVal.toFixed(1)}</strong></label>
            <input type="range" min={0} max={80} step={0.5} value={gapVal} onChange={e => setGapVal(parseFloat(e.target.value))}
              className="w-full mt-1 accent-primary" />
            <label className="text-xs text-muted-foreground mt-3 block">pulls_per_day: <strong className="text-foreground">{ppdVal.toFixed(1)}</strong></label>
            <input type="range" min={0} max={70} step={0.5} value={ppdVal} onChange={e => setPpdVal(parseFloat(e.target.value))}
              className="w-full mt-1 accent-primary" />
          </div>
          <div style={{ height: 220 }}>
            <PlotlyChart data={[{
              type: 'indicator',
              mode: 'gauge+number',
              value: knnResult.mean,
              title: { text: 'Estimated risk', font: { size: 12 } },
              gauge: { axis: { range: [0, 100] }, bar: { color: 'hsla(0,80%,58%,0.95)' } },
            }]} layout={{ margin: { t: 40, b: 10, l: 20, r: 20 } }} />
          </div>
        </div>
      </div>
    </PanelCard>
  );
}
