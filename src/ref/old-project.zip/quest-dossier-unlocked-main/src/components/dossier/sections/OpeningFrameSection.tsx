import React from 'react';
import { DATA } from '@/data/dossierData';

export function OpeningFrameSection() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="intro" className="glass-panel p-6 mb-4">
      <div className="max-w-3xl">
        <h1 className="text-3xl font-black tracking-wider text-primary mb-2">
          Silent Whale — Quest Dossier
        </h1>
        <p className="text-lg text-foreground/90 font-medium mb-1">
          Genshin Impact Player Intelligence Framework
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed mb-6">
          An evidence-driven segmentation that triangulates behavioral telemetry, private player-state surveys, 
          and public voice analysis to produce actionable player intelligence for retention strategy.
        </p>

        <div className="flex gap-3 flex-wrap mb-6">
          <button onClick={() => scrollTo('board')}
            className="px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:brightness-105 transition-all">
            🔍 Start Investigation
          </button>
          <button onClick={() => scrollTo('verdict')}
            className="px-5 py-2.5 rounded-xl border border-primary/30 text-foreground font-bold text-sm hover:bg-primary/10 transition-all">
            ⚖️ View Final Verdict
          </button>
        </div>

        {/* Case Status Panel */}
        <div className="glass-panel p-4">
          <h3 className="text-xs font-black text-primary tracking-wide mb-3">CASE STATUS — ANALYTICAL HIERARCHY</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-ok/40 text-ok mt-0.5">RETAINED</span>
                <div>
                  <p className="text-xs text-foreground font-medium">Behavior segmentation</p>
                  <p className="text-[10px] text-muted-foreground">4 clusters, silhouette = 0.37, bootstrap-stable</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-ok/40 text-ok mt-0.5">RETAINED</span>
                <div>
                  <p className="text-xs text-foreground font-medium">Survey segmentation</p>
                  <p className="text-[10px] text-muted-foreground">6 clusters from 42 respondents, interpretable profiles</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-ok/40 text-ok mt-0.5">RETAINED</span>
                <div>
                  <p className="text-xs text-foreground font-medium">Cross-view synthesis (behavior + survey)</p>
                  <p className="text-[10px] text-muted-foreground">Conceptual alignment, 4 archetypes</p>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-primary/40 text-primary mt-0.5">NOT RETAINED</span>
                <div>
                  <p className="text-xs text-foreground font-medium">Public voice + behavior direct fusion</p>
                  <p className="text-[10px] text-muted-foreground">No player-level linkage possible</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-warn/40 text-warn mt-0.5">DEMO ONLY</span>
                <div>
                  <p className="text-xs text-foreground font-medium">Synthetic hybrid (behavior + survey)</p>
                  <p className="text-[10px] text-muted-foreground">Artificial linkage, illustrative only</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border border-muted-foreground/40 text-muted-foreground mt-0.5">H4</span>
                <div>
                  <p className="text-xs text-foreground font-medium">Player-level fusion improves risk prediction</p>
                  <p className="text-[10px] text-muted-foreground">Not testable — no linked dataset available</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Hypothesis audit */}
          <div className="mt-4 pt-3 border-t border-primary/10">
            <h4 className="text-[10px] font-bold text-muted-foreground mb-2 tracking-wide">HYPOTHESIS AUDIT</h4>
            <div className="flex flex-wrap gap-2">
              {DATA.HYPOTHESES.map(h => (
                <span key={h.id} className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-semibold border ${
                  h.status.includes('Supported') ? 'border-ok/30 text-ok' :
                  h.status.includes('Not testable') ? 'border-muted-foreground/30 text-muted-foreground' :
                  'border-warn/30 text-warn'
                }`}>
                  {h.id}: {h.status}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
