import React from 'react';
import { useDossier } from '@/context/DossierContext';
import { toast } from '@/hooks/use-toast';

interface SectionHeaderProps {
  id: string;
  title: string;
  subtitle: string;
  whyItMatters: string;
  badge?: string;
  stepId: string;
  nextStepId?: string;
  internalOnly?: boolean;
}

export function SectionHeader({ id, title, subtitle, whyItMatters, badge, stepId, nextStepId, internalOnly }: SectionHeaderProps) {
  const { markDone, state } = useDossier();
  const isDone = state.done[stepId];

  const handleLogClue = () => {
    markDone(stepId);
    toast({ title: "🔍 Clue logged", description: "Progress updated" });
    // Play sound effect
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      osc.type = 'sine';
      gain.gain.value = 0.1;
      osc.start();
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      osc.stop(ctx.currentTime + 0.3);
    } catch {}
  };

  const handleNext = () => {
    if (nextStepId) {
      const el = document.getElementById(nextStepId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id={id} className="scroll-mt-24">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <h2 className="text-lg font-black tracking-wide text-primary">{title}</h2>
            {badge && (
              <span className={cn(
                "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border",
                isDone 
                  ? "border-ok/40 text-ok" 
                  : "border-primary/30 text-muted-foreground"
              )}>
                {isDone ? '✓ logged' : badge}
              </span>
            )}
            {internalOnly && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border border-warn/40 text-warn">
                INTERNAL ONLY
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{subtitle}</p>
          <p className="text-xs text-muted-foreground/70 mt-1 italic">Why this matters: {whyItMatters}</p>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <button
            onClick={handleLogClue}
            disabled={isDone}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all",
              isDone
                ? "border border-ok/30 text-ok/60 cursor-default"
                : "border border-primary/30 text-foreground hover:bg-primary/10"
            )}
          >
            {isDone ? '✓ Logged' : 'Log clue'}
          </button>
          {nextStepId && (
            <button
              onClick={handleNext}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-primary text-primary-foreground hover:brightness-110 transition-all"
            >
              Next →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function cn(...classes: (string | false | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}
