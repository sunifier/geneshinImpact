import React from 'react';
import { cn } from '@/lib/utils';

interface PanelCardProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
}

export function PanelCard({ children, className, id }: PanelCardProps) {
  return (
    <div id={id} className={cn("glass-panel p-4 mb-4", className)}>
      {children}
    </div>
  );
}
