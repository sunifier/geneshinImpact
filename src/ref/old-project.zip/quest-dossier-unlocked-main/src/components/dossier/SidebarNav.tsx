import React, { useState } from 'react';
import { useDossier, STEPS, INTERNAL_STEPS } from '@/context/DossierContext';
import { DATA } from '@/data/dossierData';
import { PlotlyChart } from './PlotlyChart';

export function SidebarNav() {
  const { state, resetProgress } = useDossier();
  const [search, setSearch] = useState('');

  const allSteps = state.viewMode === 'internal' ? [...STEPS, ...INTERNAL_STEPS] : STEPS;
  const filtered = allSteps.filter(s => s.label.toLowerCase().includes(search.toLowerCase()));

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  // Inventory items
  const inventoryItems = [
    { k: 'brief', t: 'Case brief logged' },
    { k: 'intake', t: 'Evidence intake reviewed' },
    { k: 'forensics', t: 'Feature sanity checked' },
    { k: 'segments', t: 'Segment fingerprints confirmed' },
    { k: 'risk', t: 'Risk prioritization reviewed' },
    { k: 'voice', t: 'Topic pressure reviewed' },
    { k: 'crossview', t: 'Cross-view meaning assessed' },
    { k: 'deployment', t: 'Deployment loop drafted' },
    { k: 'verdict', t: 'Verdict finalized' },
    ...(state.viewMode === 'internal' ? [
      { k: 'validation', t: 'Stat validation captured' },
      { k: 'diagnostics', t: 'Diagnostics captured' },
    ] : []),
  ];

  // Donut data
  const seg = DATA.SEG_PROFILES;
  const donutData = [{
    type: 'pie' as const,
    labels: seg.map(s => DATA.SEG_LABELS[String(s.seg_hybrid)]),
    values: seg.map(s => s.n),
    hole: 0.55,
    marker: { colors: ['hsla(0,80%,58%,0.7)', 'hsla(0,70%,50%,0.6)', 'hsla(0,60%,45%,0.5)', 'hsla(0,90%,40%,0.8)'] },
    textfont: { size: 10 },
  }];

  // Risk histogram
  const allRisks = Object.values(DATA.SEG_RISK_ARRAYS).flat();
  const histData = [{
    x: allRisks,
    type: 'histogram' as const,
    nbinsx: 20,
    marker: { color: 'hsla(0,80%,58%,0.75)' },
  }];

  return (
    <aside className="glass-panel p-3 sticky top-20 h-[calc(100vh-96px)] overflow-auto no-print"
      style={{ minWidth: 280, maxWidth: 320 }}>
      {/* Search */}
      <input
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search steps..."
        className="w-full px-3 py-2 rounded-xl border border-primary/20 bg-background text-foreground text-sm outline-none focus:border-primary/40 mb-3"
      />

      {/* Mission Map */}
      <div className="glass-panel p-3 mb-3">
        <h3 className="text-xs font-black text-primary tracking-wide mb-2">Mission Map</h3>
        <nav className="flex flex-col gap-1">
          {filtered.map(s => (
            <button
              key={s.id}
              onClick={() => scrollTo(s.id)}
              className={`text-left text-xs px-2.5 py-1.5 rounded-lg border border-transparent transition-all hover:border-primary/20 hover:bg-primary/5 ${
                state.done[s.id] ? 'text-ok' : 'text-muted-foreground'
              } ${(s.id === 'validation' || s.id === 'diagnostics') ? 'opacity-70' : ''}`}
            >
              {state.done[s.id] ? '✓ ' : '○ '}{s.label}
              {(s.id === 'validation' || s.id === 'diagnostics') && (
                <span className="ml-1 text-[9px] text-warn">(internal)</span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Evidence Inventory */}
      <div className="glass-panel p-3 mb-3">
        <h3 className="text-xs font-black text-primary tracking-wide mb-2">Evidence Inventory</h3>
        <div className="space-y-1">
          {inventoryItems.map(item => (
            <div key={item.k} className="flex justify-between items-center gap-2 text-xs">
              <span className="text-muted-foreground truncate">{item.t}</span>
              <span className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-semibold border ${
                state.done[item.k]
                  ? 'border-ok/35 text-ok'
                  : 'border-warn/35 text-warn'
              }`}>
                {state.done[item.k] ? 'logged' : 'pending'}
              </span>
            </div>
          ))}
        </div>
        <button onClick={resetProgress}
          className="mt-3 px-2 py-1 rounded-lg text-[10px] font-bold border border-primary/25 text-muted-foreground hover:text-foreground transition-all">
          Reset progress
        </button>
      </div>

      {/* Quick Dashboard */}
      <div className="glass-panel p-3">
        <h3 className="text-xs font-black text-primary tracking-wide mb-2">Quick Dashboard</h3>
        <div style={{ height: 200 }}>
          <PlotlyChart data={donutData} layout={{ margin: { t: 5, b: 5, l: 5, r: 5 }, showlegend: false }} />
        </div>
        <div style={{ height: 180 }} className="mt-2">
          <PlotlyChart data={histData} layout={{ margin: { t: 5, b: 30, l: 35, r: 5 }, xaxis: { title: 'risk score' }, yaxis: { title: 'count' } }} />
        </div>
      </div>
    </aside>
  );
}
